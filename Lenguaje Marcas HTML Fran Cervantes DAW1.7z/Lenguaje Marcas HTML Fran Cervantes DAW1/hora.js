var fecha = new Date();
document.write("FECHA: "+fecha.getDate()+"/"+(fecha.getMonth()+1)+"/"+fecha.getFullYear()+ " HORA: "+fecha.getHours()+":"+fecha.getMinutes());